from copy import deepcopy
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

class Tree():
    def __init__(self,label,iz,der):
        self.label = label
        self.left = iz
        self.right = der

def string2Tree(A):
    conectivos = ["Y","O",">"]
    stack = []
    for c in A:
    	if c in letras:
    		stack.append(Tree(c,None,None))
    	elif c == "-":
    		formaux = Tree(c, None, stack[-1])
    		del stack[-1]
    		stack.append(formaux)
    	elif c in conectivos:
    		formaux = Tree(c, stack[-1], stack[-2])
    		del stack[-1]
    		del stack[-1]
    		stack.append(formaux)
    return stack[-1]

def Inorder(arbol):
	conectivosBinarios = ["Y","O",">"]
	if arbol.label in letras:
		return arbol.label
	elif arbol.label == "-":
		return arbol.label+Inorder(arbol.right)
	elif arbol.label in conectivosBinarios:
		return "("+Inorder(arbol.left)+arbol.label+Inorder(arbol.right)+")"
	else:
		print("Oops, rotulo incorrecto")

def hay_clausula_unit(lista):
	for n in lista:
		#print(n)
		if len(n) == 1:
			return True
	return False


def complemento(n):
	x = n#[0]
	if x[0] == '-':
		return x[1]
	else:
		return '-' + x


def unit_propagate(S, I):
	#print("Haciendo unit propagate")
	#print(S, I)
	c_vacio = []
	aux = hay_clausula_unit(S)
	#print(aux)
	while(c_vacio not in S and aux):
		for n in S:
			if len(n) == 1:
				l = n[0]
		S = [y for y in S if l not in y]
		for w in S:
			if complemento(l) in w:
				w.remove(complemento(l))
		if l[0] == '-':
			I[l[1]] = 0
		else:
			I[l] = 1
		aux = hay_clausula_unit(S)
	return S, I


def DPLL(S, I):
	S, I = unit_propagate(S, I)
	c_vacio = []
	if c_vacio in S:
		return "Insatisfacible", {}
	elif len(S) == 0:
		return "Satisfacible", I
	l = ""
	for n in S:
		for x in n:
			if x not in I.keys():
				l = x
	lBarra = complemento(l)
	if l == "":
		print("Oh oh, problemas...")
		return None
	Sp = deepcopy(S)
	Sp = [n for n in Sp if l not in n]
	for m in Sp:
		if lBarra in m:
			m.remove(lBarra)
	Ip = deepcopy(I)
	if l[0] == '-':
		Ip[l[1]] = 0
	else:
		Ip[l] = 1

	S1, I1 = DPLL(Sp, Ip)
	if S1 == "Satisfacible":
		return S1, I1
	else:
		Spp = deepcopy(S)
		for a in Spp:
			if complemento(l) in a:
				Spp.remove(a)
		for b in Spp:
			if l in b:
				b.remove(l)
		Ipp = deepcopy(I)
		if l[0] == '-':
			Ipp[l[1]] = 0
		else:
			Ipp[l] = 1
		return DPLL(Spp, Ipp)


def enFNC(A):
    #assert(len(A)==4 or len(A)==7), u"Fórmula incorrecta!"
    B = ''
    p = A[0]
    #print('p', p)
    if "-" in A:
        q = A[-1]
        # print('q', q)
        B = "-"+p+"O-"+q+"Y"+p+"O"+q
    elif "Y" in A:
        q = A[3]
        # print('q', q)
        r = A[5]
        # print('r', r)
        B = q+"O-"+p+"Y"+r+"O-"+p+"Y-"+q+"O-"+r+"O"+p
    elif "O" in A:
        q = A[3]
        # print('q', q)
        r = A[5]
        # print('r', r)
        B = q+"O"+p+"Y-"+r+"O"+p+"Y"+q+"O"+r+"O-"+p
    elif ">" in A:
        q = A[3]
        # print('q', q)
        r = A[5]
        # print('r', r)
        B = q+"O"+p+"Y-"+r+"O"+p+"Y-"+q+"O"+r+"O-"+p
    else:
        print(u'Error enENC(): Fórmula incorrecta!')

    return B

def Tseitin(A, letrasProposicionalesA):
    letrasProposicionalesB = [chr(x) for x in range(256, 500000)]
    #print (letrasProposicionalesB)
    assert(not bool(set(letrasProposicionalesA) & set(letrasProposicionalesB))), u"¡Hay letras proposicionales en común!"
    L =[]
    Pila = []
    i = -1
    s = A[0]
    atomo = letrasProposicionalesA + letrasProposicionalesB
    while len(A) > 0:
        if s in (letrasProposicionalesA or letrasProposicionalesB) and Pila[-1] == '-' and len(Pila) > 0:#modificacion.
            i += 1
            atomo = letrasProposicionalesB[i]
            Pila = Pila[:-1]
            Pila.append(atomo + "=" + '-' + s)
            A = A[1:]
            s = A[0]
            if len(A) > 0:
                s = A[0]
        elif s == ')':
            w = Pila[-1]
            #print('w: ', w)
            o = Pila[-2]
            v = Pila[-3]
            Pila = Pila[:len(Pila)-4]
            i += 1
            atomo = letrasProposicionalesB[i]
            L.append(atomo + "=" + "(" + v + o + w + ")")
            s = atomo
        else:
            Pila.append(s)
            A = A[1:]
            if len(A) > 0:
                s = A[0]
    B = ''
    if i < 0:
        atomo = Pila[-1]
    else:
        atomo = letrasProposicionalesB[i]
    for X in L:
        Y = enFNC(X)
        B += "Y" + Y
    B = atomo + B
    return B
    return "OK"

def Clausula(C):
    L = []
    while len(C) > 0:
        s = C[0]
        if s == "O":
            C = C[1:]
        elif s == "-":
            literal = s + C[1]
            L.append(literal)
            C = C[2:]
        else:
            L.append(s)
            C = C[1:]
    return L
    return "OK"

def formaClausal(A):
    L = []
    i = 0
    while len(A) > 0:
        if i >= len(A):
            L.append(Clausula(A))
            A = []
        else:
            if A[i] == "Y":
                L.append(Clausula(A[:i]))
                A = A[i + 1:]
                i = 0
            else:
                i += 1
    return L
    return "OK"

def letrasProposicionales(disco, posicion, torre, ronda):
    letras = []
    primera_ronda = True
    for r in ronda:
        if primera_ronda:
            for d in disco:
                letras.append(d + posicion[disco.index(d)] + torre[0] + r)
                primera_ronda = False
        else:
            for t in torre:
                for p in posicion:
                    if int(r)%2 == 0:
                        letras.append(disco[0] + p + t + r)
                    else:
                        letras.append(disco[1] + p + t + r)
    return letras

def regla_inicial(letras):
    inicial = True
    iniciales = [x for x in letras if int(x[3]) == 1]
    regla = ""
    for p in iniciales:
        if inicial == True:
            regla = p
            inicial = False
        else:
            regla = p + regla + "Y"
    return regla

def regla_movimiento(letras, ronda):
    inicial = True
    regla = ""
    for i in range(2, len(ronda)):
        aux1 = [x for x in letras if int(x[3]) == i]
        primera = True
        subreg = []
        for p in aux1:
            regla_p = p
            aux2 = [x + "-" for x in aux1 if x != p]
            for q in aux2:
                regla_p = q + regla_p + "Y"
            if p[2] == "b" and p[3] == "2":
                subreg = [regla_p] + subreg
            elif p[2] == "c" and p[3] == "4":
                subreg = [regla_p] + subreg
            else:
                subreg.append(regla_p)
        for r in subreg:
            if primera:
                regla_ronda = r
                primera = False
            else:
                regla_ronda = regla_p + regla_ronda + "O"
        if inicial:
            regla = regla_ronda
            inicial = False
        else:
            regla = regla_ronda + regla + "O"
    return regla


def regla_cantidad_posicion(letras, posicion, torre, ronda):
    inicial = True
    regla = ""
    for i in range(1,len(ronda)):
        aux1disco1 = [x for x in letras if int(x[3]) == i]
        aux1disco2 = [x for x in letras if int(x[3]) == i + 1]
        for j in range(len(torre)):
            aux2disco1 = [x for x in aux1disco1 if torre.index(x[2]) == j]
            aux2disco2 = [x for x in aux1disco2 if torre.index(x[2]) == j]
            for p in aux2disco1:
                regla_posicion = p
                aux3 = [x + "-" for x in aux2disco2 if x[1] == p[1]]
                for q in aux3:
                    regla_posicion = q + regla_posicion + ">"
                if inicial:
                    regla = regla_posicion
                    inicial = False
                else:
                    regla = regla_posicion + regla + "Y"
    return regla

def regla_tamaño(letras, disco, torre):
    inicial = True
    regla = ""
    for i in range(2, len(ronda)):
        aux1disco1 = [x for x in letras if int(x[3]) == i]
        aux1disco2 = [x for x in letras if int(x[3]) == i + 1]
        for j in range(len(torre)):
            aux2disco1 = [x for x in aux1disco1 if torre.index(x[2]) == j]
            aux2disco2 = [x for x in aux1disco2 if torre.index(x[2]) == j]
            for p in aux2disco1:
                regla_posicion = p
                negaciones = ""
                primera = True
                aux3 = [x + "-" for x in aux2disco2 if (disco.index(p[0]) < disco.index(x[0]))]
                for q in aux3:
                    if primera:
                        negaciones = q
                        primera = False
                    else:
                        negaciones = q + negaciones + "Y"
                    regla_posicion = negaciones + regla_posicion + ">"
                    if inicial:
                        regla = regla_posicion
                        inicial = False
                    else:
                        regla = regla_posicion + regla + "Y"
    return regla

def regla_tamano(letras, disco, torre):
  inicial = True
  regla = ""
  for i in range(2, len(ronda)):
      aux1disco1 = [x for x in letras if int(x[3]) == i]
      aux1disco2 = [x for x in letras if int(x[3]) == i + 1]
      for j in range(len(torre)):
          aux2disco1 = [x for x in aux1disco1 if torre.index(x[2]) == j]
          aux2disco2 = [x for x in aux1disco2 if torre.index(x[2]) == j]
          for p in aux2disco1:
              regla_posicion = p
              negaciones = ""
              primera = True
              aux3 = [x + "-" for x in aux2disco2 if (disco.index(p[0]) < disco.index(x[0])) and int(p[1]) > int(x[1])]
              if len(aux3) > 0:
                  for q in aux3:
                      if primera:
                          negaciones = q
                          primera = False
                      else:
                          negaciones = q + negaciones + "Y"
                  regla_posicion = negaciones + regla_posicion + ">"
                  if inicial:
                      regla = regla_posicion
                      inicial = False
                  else:
                      regla = regla_posicion + regla + "Y"
  return regla

def regla_flotar(letras, disco, ronda):
    inicial = True
    regla = ""
    aux1 = [x for x in letras if x[1] == "1"]
    aux2 = [x for x in aux1 if int(x[3]) > 2]
    aux3 = [x + "-" for x in aux1 if (x not in aux2 and int(x[3]) > 1)]
    for p in aux3:
        if inicial:
            regla = p
            inicial = False
        else:
            regla = p + regla + "Y"
    for p in aux2:
        aux4 = [x + "-" for x in letras if (int(x[3]) == int(p[3]) - 1 and x[2] == p[2] and int(x[1]) == 2)]
        for q in aux4:
            if disco.index(p[0]) < disco.index(q[0]):
                regla_flota = p + "-" + q + ">"
                regla = regla_flota + regla + "Y"
    return regla

def regla_final(letras, disco, ronda):
    inicial = True
    regla = ""
    aux1 = [x for x in letras if (int(x[3]) + disco.index(x[0])) == len(ronda)]
    aux2 = [x for x in aux1 if x[2] == "c"]
    correctas = [x for x in aux2 if (disco.index(x[0]) + 1) == int(x[1])]
    incorrectas = [x + "-" for x in aux1 if x not in correctas]
    for p in correctas:
        if inicial:
            regla = p
            inicial = False
        else:
            regla = p + regla + "Y"
    for q in incorrectas:
        regla = q + regla + "Y"
    return regla

def Tseitin1(A, letrasProposicionalesA):
    letrasProposicionalesB = [chr(x) for x in range(256, 500000)]
    assert(not bool(set(letrasProposicionalesA) & set(letrasProposicionalesB))), u"¡Hay letras proposicionales en común!"
    L =[]
    Pila = []
    i = -1
    s = A[0]
    #atomo = letrasProposicionalesA + letrasProposicionalesB
    while len(A) > 0:
        if s in (letrasProposicionalesA or letrasProposicionalesB) and Pila[-1] == '-' and len(Pila) > 0:#modificacion.
            i += 1
            atomo = letrasProposicionalesB[i]
            Pila = Pila[:-1]
            Pila.append(atomo)
            L.append(atomo+'='+'-'+s)
            A = A[1:]
            if len(A) > 0:
                s = A[0]
        elif s == ')':
            w = Pila[-1]
            o = Pila[-2]
            v = Pila[-3]
            Pila = Pila[:len(Pila)-4]
            i += 1
            atomo = letrasProposicionalesB[i]
            L.append(atomo + "=" + "(" + v + o + w + ")")
            s = atomo
        else:
            Pila.append(s)
            A = A[1:]
            if len(A) > 0:
                s = A[0]
    B = ''
    if i < 0:
        atomo = Pila[-1]
    else:
        atomo = letrasProposicionalesB[i]
    for X in L:
        Y = enFNC(X)
        B += "Y" + Y
    B = atomo + B
    return B
    return "OK"


disco = ["a", "b"]
posicion = [str(i) for i in range(1, len(disco)+1)]
torre = ["a", "b", "c"]
ronda = ["1", "2", "3", "4"]

letrask = letrasProposicionales(disco, posicion, torre, ronda)
regla_movimiento(letrask, ronda)
regla_cantidad_posicion(letrask, posicion, torre, ronda)
regla_tamano(letrask, disco, torre)
regla_flotar(letrask, disco, ronda)
#print(regla_final(letras, disco, ronda))

#print(letras)
#print(len(letras))

letrasprop ={"a1a1" : 'a', "b2a1" : 'b', "a1a2" : 'c' ,"a2a2" : 'd',"a1b2" : 'e',"a2b2" : 'f' ,"a1c2" : 'g', "a2c2" : 'h', "b1a3" : 'i', "b2a3" : 'j', "b1b3" : 'k' ,"b2b3" : 'l',"b1c3" : 'm',"b2c3" : 'n',"a1a4" : 'o',"a2a4" : 'p',"a1b4" : 'q',"a2b4" : 'r',"a1c4" : 's',"a2c4" : 't'}


#regla = "n>m>l>k>j>i>n-m-YYh>n-m-Yi>n-m-Yh>n-m-Yg>l-k-Yf>l-k-Ye>j-i-Yd>j-i-Yc>YYYYYYYYYYY"
letras = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t']

#REGLAS

a = regla_inicial(letrask)
b = regla_final(letrask, disco, ronda)
c = regla_tamano(letrask, disco, torre)
d = regla_movimiento(letrask, ronda)
e = regla_cantidad_posicion(letrask, posicion, torre, ronda)
f = regla_flotar(letrask, disco, ronda)

#print (a)
#print (b)
#print (c)
print (d)
#print (e)
#print (f)

# REESCRIBIENDO REGLAS
# REGLAS a

def convert(a):
	conectivos = ["Y", "O", ">"]
	f = ""
	i = 0

	while len(a) > 0:
		if a[i] in conectivos:
			f += a[i]
			a = a[1:]
		elif a[i] + a[i+1]+ a[i+2]+ a[i+3]  in letrasprop:
			 e = letrasprop[a[i] + a[i+1]+ a[i+2]+ a[i+3]]
			 if a[i+4] == "-":
			 	e = e + "-"
			 	if len(a) > 5:
			 		a = a[5:]
			 else:
			 	if len(a) > 4:
			 		a = a[4:]
			 f += e
	return f

ac = convert(a)
bc = convert(b)
cc = convert(c)
dc = convert(d)
ec = convert(e)
fc = convert(f)

#print(ac)
#print(bc)
#print(cc)
#print(dc)
#print(ec)
#print(fc)
ner = ac + bc + cc + dc + ec + fc + "YYYYY"

print(DPLL(formaClausal(Tseitin1(Inorder(string2Tree(dc)), letras)),{'f': 1}))


print()
print("################################")
print()

print(ner)


print()
print("################################")
print()

h = string2Tree(ner)
print("yes")
h1 = Inorder(h)
print("yes")
print(h1)
h2 = Tseitin1(h1, letras)
print("yes")
print(h2)
h3 = formaClausal(h2)
print("yes")
dpll = DPLL(h3, {})
print(dpll)
print()

def diccionario(dic): #retorna un diccionario con los valores de las 64 letras proposicionales.
    d = {}
    for n in dic.keys():
        if n in letras:
            d[n] = dic[n]
    return d

print(dpll[1])
print(type(dpll[1]))


answer = diccionario(dpll[1])

    # Python3 code to demonstrate
# swap of key and value

# initializing dictionary
#old_dict = {'A': 67, 'B': 23, 'C': 45, 'D': 56, 'E': 12, 'F': 69, 'G': 67, 'H': 23}

new_dict = dict([(value, key) for key, value in letrasprop.items()])

# Printing original dictionary
print ("Original dictionary is : ")
print(letrasprop)

print()

# Printing new dictionary after swapping keys and values
print ("Dictionary after swapping is : ")
print("keys: values")
for i in new_dict:
	print(i, " : ", new_dict[i])

h = 0
strf = ""
inicial = True

for i in answer:
    k = new_dict[i]
    print(k , " : " , answer[i])
    if answer[i] == 1:
        if inicial:
            strf = k
            inicial = False
        else:
            strf = k + "Y" + strf
    h += 1

print(answer)
print(h)
print(len(answer))

print(strf)


i = 0
let = strf.split("Y")
letras2 = []
num = -2
while num < 3:
    letras2.append(let[num])
    num += 1
print(letras2)


i = 1
while i < len(letras2):
    if letras2[i][:3] == "b2a" and letras2[i-1][:3] == "a1a":
        img=mpimg.imread('op1.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a2b" and letras2[i-1][:3] == "b2a":
        img=mpimg.imread('op4.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "b2c" and letras2[i-1][:3] == "a2b":
        img=mpimg.imread('op5.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a1c" and letras2[i-1][:3] == "b2c":
        img=mpimg.imread('op3.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a2a" and letras2[i-1][:3] == "b2c":
        img=mpimg.imread('op9.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "b2b" and letras2[i-1][:3] == "a2a":
        img=mpimg.imread('op6.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a1b" and letras2[i-1][:3] == "b2b":
        img=mpimg.imread('op2.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a2c" and letras2[i-1][:3] == "b2b":
        img=mpimg.imread('op7.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "b2a" and letras2[i-1][:3] == "a2c":
        img=mpimg.imread('op8.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a1b" and letras2[i-1][:3] == "b2a":
        img=mpimg.imread('op1.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1
        #TERMINA MAL

    elif letras2[i][:3] == "a2b" and letras2[i-1][:3] == "b2a":
        img=mpimg.imread('op4.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1


    elif letras2[i][:3] == "a2c" and letras2[i-1][:3] == "b2a":
        img=mpimg.imread('op8.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "b2b" and letras2[i-1][:3] == "a2c":
        img=mpimg.imread('op7.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a1b" and letras2[i-1][:3] == "b2b":
        img=mpimg.imread('op2.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a2a" and letras2[i-1][:3] == "b2b":
        img=mpimg.imread('op6.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "b2c" and letras2[i-1][:3] == "a2a":
        img=mpimg.imread('op9.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a1c" and letras2[i-1][:3] == "b2c":
        img=mpimg.imread('op3.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a2b" and letras2[i-1][:3] == "b2c":
        img=mpimg.imread('op5.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "b2a" and letras2[i-1][:3] == "a2b":
        img=mpimg.imread('op4.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a1a" and letras2[i-1][:3] == "b2a":
        img=mpimg.imread('op1.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1

    elif letras2[i][:3] == "a2c" and letras2[i-1][:3] == "b2a":
        img=mpimg.imread('op8.png')
        imgplot = plt.imshow(img)
        plt.show()
        i+=1
